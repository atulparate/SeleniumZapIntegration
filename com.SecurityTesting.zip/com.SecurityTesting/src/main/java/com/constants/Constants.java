package com.constants;

public class Constants {

	public Constants() {
		// TODO Auto-generated constructor stub
		
	}
	
	public static String appURL = "https://opensource-demo.orangehrmlive.com/";

}
