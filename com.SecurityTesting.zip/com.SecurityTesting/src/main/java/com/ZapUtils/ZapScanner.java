package com.ZapUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.zaproxy.clientapi.core.ApiResponse;
import org.zaproxy.clientapi.core.ApiResponseElement;
import org.zaproxy.clientapi.core.ApiResponseList;
import org.zaproxy.clientapi.core.ApiResponseSet;
import org.zaproxy.clientapi.core.ClientApi;
import org.zaproxy.clientapi.core.ClientApiException;

import com.constants.Constants;

public class ZapScanner {

	private static final String SECURITY_RISK_HIGH = "High";
	private static final String SECURITY_RISK_MEDIUM = "Medium";
	private static final String SECURITY_RISK_LOW = "Low";
	private static final String SECURITY_RISK_INFORMATIONAL = "Informational";
	private static ClientApi clientApi = new ClientApi("127.0.0.1", 8080, "ste4f6cnbl1t0v0ai3qb8is50v");
	private static String securityTestReportPath = "target/zap-security-report.html";
	private static final String TARGET = "https://opensource-demo.orangehrmlive.com/"; //url of the website
	
	
	private static List<String> blackListPlugins = Arrays.asList("1000", "1025");
	
	public static void waitForPassiveScanToComplete() throws ClientApiException, InterruptedException {
        System.out.println("--- Waiting for passive scan to finish --- ");
        
			
        try {
        	Thread.sleep(10000);
            clientApi.pscan.enableAllScanners();

            ApiResponse response = clientApi.pscan.recordsToScan();

            while (!response.toString().equals("0")) {
                response = clientApi.pscan.recordsToScan();
                System.out.println(response);
            }
        } catch (ClientApiException e) {
            throw new ClientApiException("Was zap proxy started?", e);
        }
        
    }
	
	public void getScanResults() {
		try {
			 int start = 0;
	            int count = 5000;
	            int alertCount = 0;
	            ApiResponse resp = clientApi.alert.alerts(TARGET, String.valueOf(start), String.valueOf(count), null);

	            while (((ApiResponseList) resp).getItems().size() != 0) {
	                System.out.println("Reading " + count + " alerts from " + start);
	                alertCount += ((ApiResponseList) resp).getItems().size();

	                for (ApiResponse l : (((ApiResponseList) resp).getItems())) {

	                    Map<String, ApiResponse> element = ((ApiResponseSet) l).getValuesMap();
	                    if (blackListPlugins.contains(element.get("pluginId").toString())) {
	                    } else if ("High".equals(element.get("risk").toString())) {

	                    } else if ("Informational".equals(element.get("risk").toString())) {
	                    }
	                }
	                start += count;
	                resp = clientApi.alert.alerts(TARGET, String.valueOf(start), String.valueOf(count), null);
	            }
	            System.out.println("Total number of Alerts: " + alertCount);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void activeScan(String targetURL) throws InterruptedException, ClientApiException {

        // Start active scan
        ApiResponse resp = clientApi.ascan.scan(targetURL, "True", "False", null, null, null);
        int progress;

        String scanId = ((ApiResponseElement) resp).getValue();

        do {
            Thread.sleep(5000);
            progress = Integer.parseInt(((ApiResponseElement) clientApi.ascan.status(scanId)).getValue());
        } while (progress < 100);
        System.out.println("Active scan complete");
    }
	
	 public static void spiderTarget(String targetURL) throws InterruptedException, ClientApiException {
	        String application_base_url = Constants.appURL;
	        
	        // Start spider scan
	        ApiResponse apiResponse = clientApi.spider.scan(targetURL, null, null, null, null);
	        int progress;

	        String scanId = ((ApiResponseElement) apiResponse).getValue();
	        do {
	            Thread.sleep(5000);
	            progress = Integer.parseInt(((ApiResponseElement) clientApi.spider.status(scanId)).getValue());
	            System.out.println("Scan progress: " + progress + "%");
	        } while (progress < 100);
	        System.out.println("Scan Completed");

	        List<ApiResponse> spiderResults = ((ApiResponseList) clientApi.spider.results(scanId)).getItems();
	        System.out.println("spider results " + spiderResults);
	        
	    }
	
	public static void generateScanReport() throws ClientApiException, IOException {
        byte[] bytes = clientApi.core.htmlreport();
        // generate and store html report
        String str = new String(bytes, StandardCharsets.UTF_8);
        File newTextFile = new File("C:\\Users\\Atul\\eclipse-workspace\\com.SecurityTesting\\target\\htmlreport\\zapReport.html");
        
        try {
        	FileWriter fw = new FileWriter(newTextFile);
        	fw.write(str);
		} catch (Exception e) {
			// TODO: handle exception
		}
        
       
    }
}
