package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.webdriver.GetDriverInstance;

public class HomePage {

	
	WebDriver driver;
	
	public HomePage() {
		driver = GetDriverInstance.driver;
		
	}
	
	public void NavigateToApp() {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.get("https://opensource-demo.orangehrmlive.com/");	
		WebElement username = driver.findElement(By.id("txtUsername"));
		WebElement password = driver.findElement(By.id("txtPassword"));
		WebElement login = driver.findElement(By.id("btnLogin"));
		
		username.sendKeys("Admin");
		password.sendKeys("admin123");
		login.click();
	}
	
	public void NavigateToUsers() {
		Actions a = new Actions(driver);
		
		WebElement adminModule = driver.findElement(By.id("menu_admin_viewAdminModule"));
		WebElement userManagementModule = driver.findElement(By.id("menu_admin_UserManagement"));
		WebElement userModule = driver.findElement(By.id("menu_admin_viewSystemUsers"));
		
		a.moveToElement(adminModule).moveToElement(userManagementModule).moveToElement(userModule).build().perform();
	}

}
