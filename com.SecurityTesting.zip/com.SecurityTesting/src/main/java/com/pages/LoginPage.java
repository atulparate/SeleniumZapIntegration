package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.constants.Constants;
import com.webdriver.GetDriverInstance;

public class LoginPage {

	WebDriver driver;
	
	public LoginPage() {
		// TODO Auto-generated constructor stub
		driver = new GetDriverInstance().getDriver();
	}
	
	public void NavigateToApplication() {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		//driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.get(Constants.appURL);
	}
	
	public void LoginToApplication() {
		WebElement username = driver.findElement(By.id("txtUsername"));
		WebElement password = driver.findElement(By.id("txtPassword"));
		WebElement login = driver.findElement(By.id("btnLogin"));
		
		username.sendKeys("Admin");
		password.sendKeys("admin123");
		login.click();
	}

}
