package com.StepDefinition;

import java.io.IOException;

import org.zaproxy.clientapi.core.ClientApiException;

import com.ZapUtils.ZapScanner;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.webdriver.GetDriverInstance;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class testSteps {

	LoginPage loginpage = new LoginPage();
	HomePage homepage = new HomePage();
	public testSteps() {
		// TODO Auto-generated constructor stub
	}
	@Given("User Navigates to URL")
	public void user_navigates_to_url() {
		loginpage.NavigateToApplication();
	}
	@When("User Performs Security Scan")
	public void user_performs_security_scan() throws InterruptedException {
		try {
			//ZapScanner.waitForPassiveScanToComplete();
			ZapScanner.activeScan(GetDriverInstance.getCurrentURL());
		} catch (ClientApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Then("User shows reports")
	public void user_shows_reports() {
	    GetDriverInstance.closeBrowser();
	    try {
			ZapScanner.generateScanReport();
		} catch (ClientApiException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Given("Enters valid login details")
	public void enters_valid_login_details() throws InterruptedException{
		System.out.println("Inside And Statement");
		loginpage.LoginToApplication();
		homepage.NavigateToUsers();
	}
}
